﻿README for California Recreation Facilities Data

Released: June 5, 2012

This data was collected by GreenInfo Network (www.greeninfo.org), on behalf of the California Dept. of Parks & Recreation during April-June, 2012 for use in their planning projects and in promoting recreation generally. .  For more information: Amanda Recinos, Senior GIS Specialist   email: amanda@greeninfo.org

A beta web site to view the data is at:  www.parkinfo.org/recreation 


This data currently contains almost 15,000 GIS points, identifying eight different types of recreational facilities within cities in California: 
 
	•Aquatic Facility
	•Skate Park
	•Ball Field (includes football, baseball and soccer.  Must have some sort of equipment on field. Grassy areas without indications of a field sport were omitted) 
	•Covered Picnic Areas (Picnic tables without a roof were not inventoried)
	•Playground
	•Racquet Court
	•Basketball Court
	•Community Center (senior, community, nature, recreation)




All points were manually entered by GreenInfo staff and interns, using a MapCollaborator(tm) web mapping interface.  Sources used included a combination of information gathered from city websites and also visual inspection/discovery of located facilities.  Facilities needed to be open to the public (as best as could be determined) to be counted.  School facilities were excluded except if noted as explicitly open to public use.  Although data gatherers tried to be as thorough as possible, there are undoubtedly recreational facilities in urban areas (cities) that were missed or wrongly encoded. GreenInfo believes that most of the data is very comprehensive, except for community centers and indoor swim facilities which were difficult to discern.  


If a park had more than one type of a given recreational facility, a point was placed in between those facilities and a quantity noted (unless the facilities were over (approximately) a quarter mile distant from one another in which case each occurence was given a point location. For example, a group of adjacent ball fields would receive one GIS point and a quantity of "3", and the point would be placed in the middle of all three ball fields.  

Future project work will likely extend this inventory to non-city areas and completely identify all listed facilities in city areas through more intensive research of city and recreation agency web sites. 

Data was not primarily collected from agency sources so the identification of the owning agency is not exact. Based on methods of ascertaining the owning agency described below, a website link is attached to most recreational facilities. The website was attributed with the recreational facility using The California Protected Areas Database (CPAD) (found at CALands.org). Any facility within a CPAD polygon was given the owning agency's website- except for any CPAD polygon which has Restricted (permit required) or No/Closed Access. 


Any recreational facility that is greater than 1m and fewer than 25m away from a CPAD polygon was also given the closest CPAD polygon’s owning agencies website.  Any recreational facility in this category was also thinned further by removing any website that was not associated with a city or a special district. 
	
These efforts were made to ensure the link between the recreational facility and the owning agency's website is accurate.  Of the 14,636 recreational facilities, 1,482 facilities currently do not have a website associated with them, due to this process. 


END
  
